import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });
}

// ----------------------------------------------------------------------
// 1. Gemini AI WSR Analysis Endpoint
// ----------------------------------------------------------------------
app.post('/api/gemini/analyze', async (req, res) => {
  const { teams = [], dateRange = '10th Aug – 15th Aug 2026' } = req.body || {};

  if (!teams || !Array.isArray(teams)) {
    return res.status(400).json({ error: 'Invalid teams data provided.' });
  }

  if (!ai) {
    // Fallback deterministic analysis if API key is pending
    const fallbackReport = generateLocalWsrAnalysis(teams, dateRange);
    return res.json(fallbackReport);
  }

  try {
    const prompt = `Analyze the following Weekly Status Report (WSR) data for our company teams from ${dateRange}.
Teams & Timesheet Data:
${JSON.stringify(teams, null, 2)}

Provide an in-depth, executive-level WSR intelligence report evaluating:
1. Overall executive summary for leadership.
2. Team-by-team performance highlights, productivity percentage, top performer, and concerns.
3. Overtime and burnout risk alerts for employees exceeding 48 hours or with disproportionate non-productive hours (e.g. Sanjay J with 58.41 hrs, Mohamed Yasin with 57.95 hrs, Vignesh Raja with 56.48 hrs).
4. Concrete talking points for the Monday Morning Manager Standup.
5. Resource and task distribution recommendations (especially resolving carry-forward tasks).`;

    let responseText = '';
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          systemInstruction:
            'You are an executive HR and engineering productivity analyst for OfficeHub360. Analyze timesheets, billable vs non-billable hours, productive ratios, task completion rates, and burnout risks. Return clean structured JSON.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              executiveSummary: {
                type: Type.STRING,
                description: 'Executive summary paragraph highlighting weekly output, total hours, and delivery pace.'
              },
              teamHighlights: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    teamName: { type: Type.STRING },
                    summary: { type: Type.STRING },
                    productivityScore: { type: Type.NUMBER, description: 'Score out of 100' },
                    concerns: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING }
                    },
                    topPerformer: { type: Type.STRING }
                  },
                  required: ['teamName', 'summary', 'productivityScore', 'concerns', 'topPerformer']
                }
              },
              overtimeAlerts: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    employeeName: { type: Type.STRING },
                    teamName: { type: Type.STRING },
                    totalHours: { type: Type.NUMBER },
                    riskLevel: { type: Type.STRING, description: 'high, medium, or low' },
                    reason: { type: Type.STRING }
                  },
                  required: ['employeeName', 'teamName', 'totalHours', 'riskLevel', 'reason']
                }
              },
              standupTalkingPoints: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              recommendations: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              burnoutRiskCount: {
                type: Type.NUMBER,
                description: 'Total number of high-risk overloaded individuals.'
              }
            },
            required: [
              'executiveSummary',
              'teamHighlights',
              'overtimeAlerts',
              'standupTalkingPoints',
              'recommendations',
              'burnoutRiskCount'
            ]
          }
        }
      });
      responseText = response.text || '';
    } catch {
      return res.json(generateLocalWsrAnalysis(teams, dateRange));
    }

    try {
      const parsed = JSON.parse(responseText || '{}');
      if (parsed && parsed.executiveSummary) {
        return res.json(parsed);
      }
    } catch {
      // JSON parse fallback
    }
    return res.json(generateLocalWsrAnalysis(teams, dateRange));
  } catch {
    return res.json(generateLocalWsrAnalysis(teams, dateRange));
  }
});

// ----------------------------------------------------------------------
// 2. Gemini AI Interactive Chatbot Endpoint
// ----------------------------------------------------------------------
app.post('/api/gemini/chat', async (req, res) => {
  try {
    const { message, conversationHistory = [], teams = [] } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message is required.' });
    }

    if (!ai) {
      return res.json({
        reply: `OfficeHub360 AI Assistant: I analyzed your WSR data. In ${teams.length} teams with ${teams.reduce((a: number, t: any) => a + t.members.length, 0)} employees, total logged hours are ${teams.reduce((a: number, t: any) => a + t.members.reduce((b: number, m: any) => b + m.totalHours, 0), 0).toFixed(1)} hrs. How can I help with timesheet breakdown or standup notes?`
      });
    }

    const contextPrompt = `You are the OfficeHub360 AI WSR Assistant. You have full access to current employee timesheets, task completion metrics, billable hours, and weekly PPT slide data:
Current Team Data:
${JSON.stringify(teams, null, 2)}

User Question: ${message}

Provide a helpful, precise, formatted response (using markdown bullet points, bold highlights, or tables if helpful). Be direct and executive-friendly.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: contextPrompt,
      config: {
        systemInstruction:
          'You are an executive WSR assistant for company managers. Answer questions directly using the provided timesheet data. Provide actionable advice for sprint reviews, overtime balancing, and employee recognition.'
      }
    });

    return res.json({ reply: response.text });
  } catch (error: any) {
    console.error('Gemini Chat error:', error);
    return res.status(500).json({
      error: 'Failed to process chat message',
      reply: 'I encountered an issue processing the request. Please try asking again.'
    });
  }
});

// ----------------------------------------------------------------------
// 3. Automated Weekly WSR Bot Dispatch Simulation
// ----------------------------------------------------------------------
app.post('/api/bot/dispatch-now', async (req, res) => {
  try {
    const { config, teams, overallDateRange = '10th Aug – 15th Aug 2026' } = req.body;
    const managerEmail = config?.managerEmail || process.env.VITE_DEFAULT_MANAGER_EMAIL || 'suhaifakt01@gmail.com';

    const totalHours = teams?.reduce(
      (a: number, t: any) => a + t.members.reduce((b: number, m: any) => b + m.totalHours, 0),
      0
    ) || 0;
    const totalTasks = teams?.reduce(
      (a: number, t: any) => a + t.members.reduce((b: number, m: any) => b + m.tasksCompleted, 0),
      0
    ) || 0;

    const emailSubject = `[OfficeHub360 WSR] Weekly Team Status Report (${overallDateRange}) - PPT Attached`;

    const emailHtmlPreview = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #1e293b; background-color: #f8fafc; margin: 0; padding: 20px; }
    .container { max-width: 680px; margin: 0 auto; background: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.05); border: 1px solid #e2e8f0; }
    .header { background: #0097a7; color: #ffffff; padding: 24px; text-align: left; }
    .header h1 { margin: 0 0 6px 0; font-size: 22px; }
    .header p { margin: 0; opacity: 0.9; font-size: 14px; }
    .content { padding: 24px; }
    .kpi-grid { display: flex; gap: 12px; margin-bottom: 24px; }
    .kpi-card { flex: 1; background: #f1f5f9; padding: 14px; border-radius: 8px; border-left: 4px solid #0097a7; }
    .kpi-title { font-size: 11px; text-transform: uppercase; color: #64748b; font-weight: bold; }
    .kpi-value { font-size: 20px; font-weight: bold; color: #0f172a; margin-top: 4px; }
    .section-title { font-size: 16px; font-weight: bold; color: #0f172a; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px; margin-top: 24px; }
    .team-badge { display: inline-block; background: #e0f2fe; color: #0369a1; padding: 3px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }
    .attachment-box { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 14px; margin-top: 24px; display: flex; align-items: center; justify-content: space-between; }
    .footer { background: #f8fafc; padding: 16px 24px; font-size: 12px; color: #94a3b8; border-top: 1px solid #e2e8f0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>OfficeHub360 • Weekly Status Report</h1>
      <p>Reporting Period: <strong>${overallDateRange}</strong> • Prepared for <strong>${managerEmail}</strong></p>
    </div>
    <div class="content">
      <div class="kpi-grid">
        <div class="kpi-card">
          <div class="kpi-title">Total Hours</div>
          <div class="kpi-value">${totalHours.toFixed(1)} hrs</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-title">Tasks Done</div>
          <div class="kpi-value">${totalTasks}</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-title">Teams Reported</div>
          <div class="kpi-value">${teams?.length || 0} Teams</div>
        </div>
      </div>

      <div class="section-title">📊 Executive Summary</div>
      <p style="font-size: 14px; line-height: 1.6; color: #334155;">
        All scheduled teams have completed their timesheet logging for the week of ${overallDateRange}. The engineering output remained strong with high velocity across Python and HR Dashboard modules. A few high-overtime contributors have been flagged for manager review.
      </p>

      <div class="section-title">🎯 Team Breakdown</div>
      <ul style="font-size: 14px; line-height: 1.8; color: #334155; padding-left: 20px;">
        ${teams?.map((t: any) => `<li><strong>${t.name}</strong>: ${t.members.length} members, ${t.members.reduce((a: number, m: any) => a + m.totalHours, 0).toFixed(1)} hrs logged, ${t.members.reduce((a: number, m: any) => a + m.tasksCompleted, 0)} tasks delivered.</li>`).join('') || ''}
      </ul>

      <div class="attachment-box">
        <div>
          <strong style="color: #166534; font-size: 14px;">📎 Attached: OfficeHub360_WSR_${overallDateRange.replace(/\s+/g, '_')}.pptx</strong>
          <div style="font-size: 12px; color: #15803d; margin-top: 2px;">Slide deck generated in company executive format with separate team slides.</div>
        </div>
      </div>
    </div>
    <div class="footer">
      Automated AI Bot Dispatch from OfficeHub360 • Triggered every Monday 08:30 AM IST • Database: Supabase ofzdvvjkqgnheogwfdnk
    </div>
  </div>
</body>
</html>
    `;

    return res.json({
      success: true,
      timestamp: new Date().toISOString(),
      recipient: managerEmail,
      subject: emailSubject,
      pptxFileName: `OfficeHub360_WSR_${overallDateRange.replace(/[^a-zA-Z0-9]/g, '_')}.pptx`,
      emailHtmlPreview,
      message: `Weekly WSR PowerPoint report generated and queued for ${managerEmail}`
    });
  } catch (error: any) {
    return res.status(500).json({ error: error.message || 'Dispatch failed' });
  }
});

// Helper for deterministic rule-based analysis when AI key is loading
function generateLocalWsrAnalysis(teams: any[], dateRange: string) {
  const allMembers = teams.flatMap((t) =>
    t.members.map((m: any) => ({ ...m, teamName: t.name }))
  );
  const totalHours = allMembers.reduce((a, m) => a + m.totalHours, 0);
  const totalProductive = allMembers.reduce((a, m) => a + m.productiveHours, 0);
  const totalTasks = allMembers.reduce((a, m) => a + m.tasksCompleted, 0);
  const totalCarry = allMembers.reduce((a, m) => a + m.carryForward, 0);

  const overtimeAlerts = allMembers
    .filter((m) => m.totalHours > 50 || m.nonProductiveHours > 10)
    .map((m) => ({
      employeeName: m.name || m.displayName,
      teamName: m.teamName,
      totalHours: m.totalHours,
      riskLevel: (m.totalHours > 55 ? 'high' : 'medium') as 'high' | 'medium' | 'low',
      reason:
        m.totalHours > 55
          ? `High weekly overtime (${m.totalHours} hrs). Non-productive duration is ${m.nonProductiveHours} hrs.`
          : `Significant overtime load (${m.totalHours} hrs).`
    }));

  const teamHighlights = teams.map((t) => {
    const tTotal = t.members.reduce((a: number, m: any) => a + m.totalHours, 0);
    const tProd = t.members.reduce((a: number, m: any) => a + m.productiveHours, 0);
    const score = tTotal > 0 ? Math.round((tProd / tTotal) * 100) : 90;
    const top = t.members.reduce((prev: any, current: any) =>
      current.tasksCompleted > (prev?.tasksCompleted || 0) ? current : prev
    , t.members[0]);

    return {
      teamName: t.name,
      summary: `${t.name} logged ${tTotal.toFixed(1)} total hours across ${t.members.length} members with ${t.members.reduce((a: number, m: any) => a + m.tasksCompleted, 0)} completed tasks.`,
      productivityScore: score,
      concerns:
        t.members.some((m: any) => m.carryForward > 0)
          ? [`${t.members.filter((m: any) => m.carryForward > 0).length} member(s) have carry-forward tasks.`]
          : ['No pending blockers identified.'],
      topPerformer: top ? `${top.displayName} (${top.tasksCompleted} tasks)` : 'All members on track'
    };
  });

  return {
    executiveSummary: `For the period ${dateRange}, a total of ${totalHours.toFixed(1)} hours were logged across ${teams.length} teams (${allMembers.length} active employees). Overall productive hours stood at ${totalProductive.toFixed(1)} (${((totalProductive / (totalHours || 1)) * 100).toFixed(1)}% efficiency) with ${totalTasks} tasks delivered and ${totalCarry} carry-forward items.`,
    teamHighlights,
    overtimeAlerts,
    standupTalkingPoints: [
      `Review task distribution for high-overtime engineers: Sanjay Janakiraman (58.41h) and Mohamed Yasin (57.95h).`,
      `Westcoast Team has 3 carry-forward tasks; check if client dependencies or testing approvals are holding up completion.`,
      `Python Team achieved top task throughput with Shoaib and Gokulnath both delivering 11 tasks.`,
      `Verify Timesheet holiday logging: Aakash (2 holidays) and Gokulnath (1 holiday) recorded accurate availed leaves.`
    ],
    recommendations: [
      'Rebalance client architectural workload to prevent single-point engineer fatigue on the Westcoast project.',
      'Establish automated Supabase sync validation to catch missing non-billable classifications early in the week.',
      'Ensure weekly PPT deck is shared with client stakeholders by 10:00 AM every Monday.'
    ],
    burnoutRiskCount: overtimeAlerts.filter((a) => a.riskLevel === 'high').length
  };
}

// Serve Vite build in production
const distPath = path.join(__dirname, 'dist');
app.use(express.static(distPath));

app.get('*', (_req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`OfficeHub360 AI WSR Server running on port ${PORT}`);
});
